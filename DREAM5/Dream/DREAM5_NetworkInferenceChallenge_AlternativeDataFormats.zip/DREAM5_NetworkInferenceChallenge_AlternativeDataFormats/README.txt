DREAM5 NETWORK INFERENCE CHALLENGE
ALTERNATIVE DATA FORMATS
==================================

For convenience, we give here the expression data of the challenge in two alternative formats. Please read first the description of the challenge on the DREAM website and download the official datasets on the DREAM website:

http://wiki.c2b2.columbia.edu/dream/index.php/D5c4

The data given here is the same as on the DREAM website, only the format is different. Below, we describe the files located in this directory.


NetX_expression_data_t.tsv
--------------------------

The transpose of the expression matrix given on the DREAM website. In addition, we have added labels for genes (rows) and experiments (columns). These files can be loaded for visualization using Genatomy, for example (http://www.c2b2.columbia.edu/danapeerlab/html/genatomy.html).


NetX_expression_data_avg.tsv
----------------------------

The expression matrix on the DREAM website with multiple replicates of the same experiment averaged.


NetX_chip_features_avg.tsv
--------------------------

Row k of this file gives the features for row k of the file NetX_expression_data_avg.tsv (the k'th experiment of the compendium, see the challenge description on the DREAM website for details). The number in the last column ('repeat') is the number of replicates of this experiment (i.e., the number of samples that were used to compute the average). 


NetX_expression_data_avg_t.tsv
------------------------------

The transpose of the averaged expression data given in the file NetX_expression_data_avg.tsv with labels for genes (rows) and experiments (columns) added.


For questions regarding the challenge, please use the DREAM discussion forum:
http://wiki.c2b2.columbia.edu/dream/discuss/

You may also contact:
   - Daniel Marbach (dmarbach@mit.edu)
   - Gustavo Stolovitzky (gustavo@us.ibm.com)


---
Daniel Marbach
June 9, 2010
