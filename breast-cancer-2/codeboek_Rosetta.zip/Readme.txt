There are 6 (six) txt files total containing genome-wide gene expression 
data for 295 samples in this release. 

Table_NKI_295_1.txt contains data for 50 samples.
Table_NKI_295_2.txt contains data for 50 samples.
Table_NKI_295_3.txt contains data for 50 samples.
Table_NKI_295_4.txt contains data for 50 samples.
Table_NKI_295_5.txt contains data for 50 samples.
Table_NKI_295_6.txt contains data for 45 samples.
There are total 295 samples. 

Each row in a table is for one sequence on the chip. First two columns 
give systematic substance name and gene name (if any) respectively. 
Starting 3rd column, each sample takes 5 columns for 50 samples in each table 
(except for Table 6, with 45 samples). These five columns are log(ratio), 
log(ratio) error, p-value for log(ratio) significance, log(intensity), and 
flag for each spot (= 0 for control or bad spot, = 1 for valid measurement).

Sample ID used in these tables are the same ones used in Clinical Data Table 
and 70 Gene Table.



